﻿using System;
using System.Collections.Generic;
using System.Net.Http;
using System.Net.Http.Headers;
using System.Text;
using System.Text.Json;
using System.Threading.Tasks;
using HospitalPatientManagementSystem.Frontend.Model.Dto;
using Microsoft.AspNetCore.Http;
namespace HospitalPatientManagementSystem.Frontend.Services { 
public class PatientService
{
    private readonly HttpClient _httpClient;
    private readonly IHttpContextAccessor _httpContextAccessor;

    public PatientService(HttpClient httpClient, IHttpContextAccessor httpContextAccessor)
    {
        _httpClient = httpClient;
        _httpContextAccessor = httpContextAccessor;
    }

    // Get all patients
    public async Task<IEnumerable<PatientResponseDto>> GetPatientsAsync()
    {
        var request = new HttpRequestMessage(HttpMethod.Get, "https://localhost:7100/api/Patients");
        var response = await SendRequestAsync(request);

        response.EnsureSuccessStatusCode(); // Throws if not successful
        var content = await response.Content.ReadAsStringAsync();
        return JsonSerializer.Deserialize<IEnumerable<PatientResponseDto>>(content);
    }

    // Get a single patient by ID
    public async Task<PatientResponseDto> GetPatientAsync(Guid id)
    {
        var request = new HttpRequestMessage(HttpMethod.Get, $"https://localhost:7100/api/Patients/{id}");
        var response = await SendRequestAsync(request);

        response.EnsureSuccessStatusCode(); // Throws if not successful
        var content = await response.Content.ReadAsStringAsync();
        return JsonSerializer.Deserialize<PatientResponseDto>(content);
    }

    // Create a new patient
    public async Task<bool> CreatePatientAsync(PatientDto patientDto)
    {
        var json = JsonSerializer.Serialize(patientDto);
        var content = new StringContent(json, Encoding.UTF8, "application/json");
        var request = new HttpRequestMessage(HttpMethod.Post, "https://localhost:7100/api/Patients") { Content = content };
        var response = await SendRequestAsync(request);

        return response.IsSuccessStatusCode;
    }

    // Update an existing patient
    public async Task<bool> UpdatePatientAsync(Guid id, PatientDto patientDto)
    {
        var json = JsonSerializer.Serialize(patientDto);
        var content = new StringContent(json, Encoding.UTF8, "application/json");
        var request = new HttpRequestMessage(HttpMethod.Put, $"https://localhost:7100/api/Patients/{id}") { Content = content };
        var response = await SendRequestAsync(request);

        return response.IsSuccessStatusCode;
    }

    // Delete a patient
    public async Task<bool> DeletePatientAsync(Guid id)
    {
        var request = new HttpRequestMessage(HttpMethod.Delete, $"https://localhost:7100/api/Patients/{id}");
        var response = await SendRequestAsync(request);

        return response.IsSuccessStatusCode;
    }

    // Helper method to send requests with JWT and refresh tokens
    private async Task<HttpResponseMessage> SendRequestAsync(HttpRequestMessage request)
    {
        var jwtToken = _httpContextAccessor.HttpContext.Request.Cookies["JwtToken"];
        var refreshToken = _httpContextAccessor.HttpContext.Request.Cookies["refreshToken"];

        if (!string.IsNullOrEmpty(jwtToken))
        {
            request.Headers.Authorization = new AuthenticationHeaderValue("Bearer", jwtToken);
            request.Headers.Add("JwtToken", jwtToken);
        }

        if (!string.IsNullOrEmpty(refreshToken))
        {
            request.Headers.Add("refreshToken", refreshToken);
        }

        return await _httpClient.SendAsync(request);
    }
}
}