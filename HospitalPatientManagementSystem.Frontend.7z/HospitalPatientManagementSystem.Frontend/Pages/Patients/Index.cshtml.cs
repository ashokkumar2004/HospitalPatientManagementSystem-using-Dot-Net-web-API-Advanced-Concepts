using Microsoft.AspNetCore.Mvc.RazorPages;
using System.Net.Http;
using System.Text.Json;
using HospitalPatientManagementSystem.Frontend.Model.Dto;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;

namespace HospitalPatientManagementSystem.Frontend.Pages.Patients
{
    [Authorize(Roles = "Admin,Executive")]
    public class IndexModel : PageModel
    {
        private readonly HttpClient _httpClient;

        public IndexModel(HttpClient httpClient)
        {
            _httpClient = httpClient;
        }
        [BindProperty]
        public List<PatientResponseDto> Patients { get; set; } = new List<PatientResponseDto>();

        public async Task OnGetAsync()
        {
            var token = HttpContext.Request.Cookies["JwtToken"];
            _httpClient.DefaultRequestHeaders.Authorization = new System.Net.Http.Headers.AuthenticationHeaderValue("Bearer", token);

            var response = await _httpClient.GetAsync("https://localhost:7100/api/Patients");
            if (response.IsSuccessStatusCode)
            {
                var json = await response.Content.ReadAsStringAsync();
                Patients = JsonSerializer.Deserialize<List<PatientResponseDto>>(json);
            }
        }
    }
}