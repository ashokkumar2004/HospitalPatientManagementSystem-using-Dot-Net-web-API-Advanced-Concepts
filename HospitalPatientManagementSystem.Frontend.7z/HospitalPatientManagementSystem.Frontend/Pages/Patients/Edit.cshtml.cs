using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using System.Net.Http;
using System.Text;
using System.Text.Json;
using HospitalPatientManagementSystem.Frontend.Model.Dto;
using Microsoft.AspNetCore.Authorization;

namespace HospitalPatientManagementSystem.Frontend.Pages.Patients
{
    [Authorize(Roles = "Admin")]
    public class EditModel : PageModel
    {
        private readonly HttpClient _httpClient;

        public EditModel(HttpClient httpClient)
        {
            _httpClient = httpClient;
        }

        [BindProperty]
        public PatientResponseDto Patient { get; set; }

        public async Task<IActionResult> OnGetAsync(Guid id)
        {
            var token = HttpContext.Request.Cookies["JwtToken"];
            _httpClient.DefaultRequestHeaders.Authorization = new System.Net.Http.Headers.AuthenticationHeaderValue("Bearer", token);

            var response = await _httpClient.GetAsync($"https://localhost:7100/api/Patients/{id}");
            if (response.IsSuccessStatusCode)
            {
                var json = await response.Content.ReadAsStringAsync();
                Patient = JsonSerializer.Deserialize<PatientResponseDto>(json);
                return Page();
            }
            return NotFound();
        }

        public async Task<IActionResult> OnPostAsync()
        {
            if (!ModelState.IsValid)
            {
                return Page();
            }

            var token = HttpContext.Request.Cookies["JwtToken"];
            _httpClient.DefaultRequestHeaders.Authorization = new System.Net.Http.Headers.AuthenticationHeaderValue("Bearer", token);

            var patientDto = new PatientDto
            {
                Name = Patient.Name,
                DateOfBirth = Patient.DateOfBirth,
                Phonenumber = Patient.Phonenumber,
                Address = Patient.Address
            };

            var json = JsonSerializer.Serialize(patientDto);
            var content = new StringContent(json, Encoding.UTF8, "application/json");

            var response = await _httpClient.PutAsync($"https://localhost:7100/api/Patients/{Patient.Id}", content);
            if (response.IsSuccessStatusCode)
            {
                return RedirectToPage("Index");
            }

            ModelState.AddModelError(string.Empty, "Failed to update patient.");
            return Page();
        }
    }
}