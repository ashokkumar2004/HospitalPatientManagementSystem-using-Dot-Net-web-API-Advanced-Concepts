using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using System.Net.Http;
using System.Text;
using System.Text.Json;
using HospitalPatientManagementSystem.Frontend.Model.Dto;

namespace HospitalPatientManagementSystem.Frontend.Pages.Account
{
    public class RegisterModel : PageModel
    {
        private readonly HttpClient _httpClient;

        public RegisterModel(HttpClient httpClient)
        {
            _httpClient = httpClient;
        }

        [BindProperty]
        public RegisterRequestDto RegisterRequest { get; set; }

        public void OnGet()
        {
        }

        public async Task<IActionResult> OnPostAsync()
        {
            if (!ModelState.IsValid)
            {
                return Page();
            }

            var json = JsonSerializer.Serialize(RegisterRequest);
            var content = new StringContent(json, Encoding.UTF8, "application/json");

            var response = await _httpClient.PostAsync("https://localhost:7100/api/Auth/Register", content);

            if (response.IsSuccessStatusCode)
            {
                return RedirectToPage("/Account/Login");
            }

            ModelState.AddModelError(string.Empty, "Registration failed. Please try again.");
            return Page();
        }
    }
}