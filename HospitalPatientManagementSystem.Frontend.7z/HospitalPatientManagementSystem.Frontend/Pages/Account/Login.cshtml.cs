using Microsoft.AspNetCore.Authentication;
using Microsoft.AspNetCore.Authentication.Cookies;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using System.Net.Http;
using System.Text;
using System.Text.Json;
using System.Security.Claims;
using System.Collections.Generic;
using System.Threading.Tasks;
using HospitalPatientManagementSystem.Frontend.Model.Dto;

namespace HospitalPatientManagementSystem.Frontend.Pages.Account
{
    public class LoginModel : PageModel
    {
        private readonly HttpClient _httpClient;

        public LoginModel(HttpClient httpClient)
        {
            _httpClient = httpClient;
        }

        [BindProperty]
        public LoginRequestDto LoginRequest { get; set; }

        public void OnGet()
        {
        }

        public async Task<IActionResult> OnPostAsync()
        {
            if (!ModelState.IsValid)
            {
                return Page();
            }

            var json = JsonSerializer.Serialize(LoginRequest);
            var content = new StringContent(json, Encoding.UTF8, "application/json");

            // Call the Login API
            var response = await _httpClient.PostAsync("https://localhost:7100/api/Auth/Login", content);

            if (response.IsSuccessStatusCode)
            {
                var responseContent = await response.Content.ReadAsStringAsync();
                Console.WriteLine("API Response: " + responseContent); // Log the response

                var loginResponse = JsonSerializer.Deserialize<LoginResponseDto>(responseContent);

                if (loginResponse == null)
                {
                    ModelState.AddModelError(string.Empty, "Invalid API response. Token is missing.");
                    return RedirectToPage("/Account/Login");
                }

                // Set JWT and refresh token cookies
                var expiryDate = DateTime.Now.AddDays(2);
                SetTokenCookies(loginResponse.jwttoken, loginResponse.refreshToken, expiryDate);

                // Fetch user info to get roles
                
                if (!string.IsNullOrEmpty(loginResponse.roles))
                {
                  

                    // Create claims with roles
                    var claims = new List<Claim>
                    {
                        new Claim(ClaimTypes.Name, LoginRequest.UserName),
                        new Claim("JwtToken", loginResponse.jwttoken)
                    };

                    // Add roles to claims
                    if (!string.IsNullOrEmpty(loginResponse.roles))
                    {
                        var roles = loginResponse.roles.Split(',');
                        foreach (var role in roles)
                        {
                            claims.Add(new Claim(ClaimTypes.Role, role));
                        }
                    }

                    // Sign in the user
                    var claimsIdentity = new ClaimsIdentity(claims, CookieAuthenticationDefaults.AuthenticationScheme);
                    var authProperties = new AuthenticationProperties
                    {
                        IsPersistent = true // Optional: Keep the user logged in
                    };

                    await HttpContext.SignInAsync(
                        CookieAuthenticationDefaults.AuthenticationScheme,
                        new ClaimsPrincipal(claimsIdentity),
                        authProperties);

                    return RedirectToPage("/Index");
                }
            }

            ModelState.AddModelError(string.Empty, "Login failed. Please try again.");
            return Page();
        }

        private void SetTokenCookies(string jwttoken, string refreshtoken, DateTime expirydate)
        {
            var cookieOptionsjwt = new CookieOptions
            {
                HttpOnly = true,
                Expires = DateTime.Now.AddMinutes(15),
                Secure = true,
                SameSite = SameSiteMode.None, // Allows cross-site requests
                Domain = "localhost", // Set the domain to match the backend
                Path = "/", // Ensure the cookie is accessible across all paths
            };
            var cookieOptionsrefresh = new CookieOptions
            {
                HttpOnly = true,
                Expires = expirydate,
                Secure = true,
                SameSite = SameSiteMode.None, // Allows cross-site requests
                Domain = "localhost", // Set the domain to match the backend
                Path = "/", // Ensure the cookie is accessible across all paths
            };
            Response.Cookies.Append("JwtToken", jwttoken, cookieOptionsjwt);
            Response.Cookies.Append("refreshToken", refreshtoken, cookieOptionsrefresh);
        }
    }
}