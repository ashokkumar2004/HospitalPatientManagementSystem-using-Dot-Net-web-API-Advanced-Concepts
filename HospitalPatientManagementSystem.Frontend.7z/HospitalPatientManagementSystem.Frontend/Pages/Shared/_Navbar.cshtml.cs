using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace HospitalPatientManagementSystem.Frontend.Pages.Shared
{
    public class _NavbarModel : PageModel
    {
        public void OnGet()
        {
        }
    }
}
