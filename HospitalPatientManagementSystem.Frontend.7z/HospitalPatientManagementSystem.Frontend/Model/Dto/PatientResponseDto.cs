﻿using System.ComponentModel.DataAnnotations;

namespace HospitalPatientManagementSystem.Frontend.Model.Dto
{
    public class PatientResponseDto
    {
        public Guid Id { get; set; }
        [Required(ErrorMessage = "Name is required")]
        [StringLength(100, ErrorMessage = "Name cannot exceed 100 characters")]

        public string Name { get; set; }
        public DateOnly DateOfBirth { get; set; }
        [Required]
        [MaxLength(10, ErrorMessage = "The phone number must be a 10 digit")]
        [MinLength(10, ErrorMessage = "The phone number must be a 10 digit")]
        public string Phonenumber { get; set; }

        [Required(ErrorMessage = "Name is required")]
        [StringLength(100, ErrorMessage = "Address cannot exceed 100 characters")]
        public string Address { get; set; }
    }
}
