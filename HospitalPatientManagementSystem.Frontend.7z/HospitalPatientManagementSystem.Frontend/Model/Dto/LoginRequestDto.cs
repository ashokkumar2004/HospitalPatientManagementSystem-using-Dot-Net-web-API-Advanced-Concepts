﻿using System.ComponentModel.DataAnnotations;

namespace HospitalPatientManagementSystem.Frontend.Model.Dto
{
    public class LoginRequestDto
    {
        [Required]
        [DataType(DataType.EmailAddress)]
        public string UserName { get; set; }
        [Required]
        [DataType(DataType.Password)]
        public string Password { get; set; }
    }
}
