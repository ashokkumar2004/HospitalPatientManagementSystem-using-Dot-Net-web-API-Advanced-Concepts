﻿namespace HospitalPatientManagementSystem.Frontend.Model.Dto
{
    public class LoginResponseDto
    {
        public string jwttoken { get; set; }
        public string  refreshToken{ get; set; }
        public string roles{ get; set; }  
    }
}
