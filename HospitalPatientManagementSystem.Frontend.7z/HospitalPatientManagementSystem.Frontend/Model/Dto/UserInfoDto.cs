﻿namespace HospitalPatientManagementSystem.Frontend.Model.Dto
{
    public class UserInfoDto
    {
        public string Roles { get; set; }
        public string Email { get; set; }
    }
}
