﻿namespace HospitalPatientManagementSystem.Frontend.Model.Domain
{
    public class Patient
    {
        public Guid Id { get; set; } = Guid.NewGuid();
        public string Name { get; set; }
        public DateOnly DateOfBirth { get; set; }
        public string Phonenumber { get; set; }
        public string Address { get; set; }
    }
}
